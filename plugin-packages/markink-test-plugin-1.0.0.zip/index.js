// markink plugin ZIP installation fixture.
// This file is intentionally inert; current markink builds do not execute plugin entries.
