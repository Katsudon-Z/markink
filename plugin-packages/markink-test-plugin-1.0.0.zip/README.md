# markink ZIP導入テスト

このZIPはmarkinkのプラグインZIP導入・一覧・削除を確認するためのfixtureです。

## 確認方法

1. markinkを起動し、上部の「プラグイン」を開きます。
2. 「ZIPから導入」を選び、このZIPを指定します。
3. 「markink ZIP導入テスト」、version 1.0.0、API 1、要求権限なしと表示されることを確認します。
4. 「削除」で一覧から消えることを確認します。

この版のmarkinkはプラグインruntimeをまだ備えていません。index.jsはZIP形式確認用の空のentryであり、導入しても実行されません。
