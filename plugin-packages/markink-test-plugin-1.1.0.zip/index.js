self.markinkPlugin = {
  async activate(api) {
    await api.registerCommand(
      { id: 'hello', title: 'テスト通知', placement: 'menu', description: 'プラグイン実行を確認します' },
      async () => { await api.notify('テストプラグインが実行されました'); }
    );
  }
};
